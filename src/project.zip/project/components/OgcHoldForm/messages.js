import { defineMessages } from 'react-intl';

export default defineMessages({
    toggle: {
        id: 'app.components.OgcHold.Togle',
        defaultMessage: 'Disable',
    },
});
